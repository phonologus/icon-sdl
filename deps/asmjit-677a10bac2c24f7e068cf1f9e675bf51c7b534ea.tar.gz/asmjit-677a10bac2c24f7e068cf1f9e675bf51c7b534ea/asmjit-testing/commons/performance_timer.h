// This file is part of AsmJit project <https://asmjit.com>
//
// See <asmjit/core.h> or LICENSE.md for license and copyright information
// SPDX-License-Identifier: Zlib

#ifndef ASMJIT_TESTING_COMMONS_PERFORMANCE_TIMER_H_INCLUDED
#define ASMJIT_TESTING_COMMONS_PERFORMANCE_TIMER_H_INCLUDED

#include <chrono>

class PerformanceTimer {
public:
  using TimePoint = std::chrono::steady_clock::time_point;

  TimePoint _start_time {};
  TimePoint _end_time {};

  inline void start() { _start_time = std::chrono::steady_clock::now(); }
  inline void stop() { _end_time = std::chrono::steady_clock::now(); }

  inline double duration() const {
    std::chrono::duration<double> elapsed = _end_time - _start_time;
    return elapsed.count() * 1000;
  }
};

#endif // ASMJIT_TESTING_COMMONS_PERFORMANCE_TIMER_H_INCLUDED
