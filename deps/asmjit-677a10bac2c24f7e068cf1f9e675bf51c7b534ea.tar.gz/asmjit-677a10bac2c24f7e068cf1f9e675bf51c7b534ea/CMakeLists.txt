# AsmJit
# ======

# AsmJit library provides a single alias that can use used to consume it as a dependency:
#
#   `asmjit::asmjit`
#
# Depending on options, the alias would be either a static or shared library (depending on
# `ASMJIT_STATIC=ON|OFF` options) or it would be an interface library if `ASMJIT_EMBED=ON`.
#
# NOTE: When `ASMJIT_EMBED=ON` AsmJit won't add any installation instructions of libraries
# or header files. Embed is literally for users that want to consume AsmJit as source code
# without creating an intermediate static library. C++ flags, which used by the consuming
# target will then be used to compile the embedded AsmJit source code as well. This option
# improves the control of how AsmJit is both compiled and consumed.
#
# Consuming AsmJit
# ----------------
#
# The recommended scenario to consume AsmJit is to clone it to a directory where third
# party libraries are placed (this can be done even if you use a package manager such as
# vcpkg or conan to manage other dependencies). Usually, the directory is called '3rdparty'
# and it resides in your project's root, but it's just a recommendation, not a convention.
# In such case, consuming a cloned AsmJit from your own project would look like this:
#
#   # == Configure AsmJit options ==
#   set(ASMJIT_EMBED  ON or OFF)                   # AsmJit uses ASMJIT_EMBED=OFF by default.
#   set(ASMJIT_STATIC ON or OFF)                   # AsmJit uses ASMJIT_STATIC=OFF by default.
#   add_subdirectory(3rdparty/asmjit asmjit)       # Adds AsmJit as a sub-project.
#
#   # == Consume AsmJit as a CMake dependency ==
#   add_executable(test_app main.cpp)              # Target executable having main.cpp
#   target_link_libraries(test_app asmjit::asmjit) # Adds AsmJit as a dependency to test_app.
#
# Developing & Testing AsmJit
# ---------------------------
#
# There are sample configure scripts provided, which reside in project root. In general, to
# develop AsmJit it must be configured with `ASMJIT_TEST=ON` to build AsmJit tests and they
# have to pass. Here is a simple cmake invocation to build AsmJit with tests enabled:
#
#   cmake . -B build/Debug -DCMAKE_BUILD_TYPE=Debug -DASMJIT_TEST=ON
#
# See <asmjit.com> for more details.

cmake_minimum_required(VERSION 3.24 FATAL_ERROR)

# AsmJit - Project & Configuration
# ================================

# Don't create a project if it was already created by another CMakeLists.txt. This makes
# it possible to support both add_subdirectory() and include() ways of using AsmJit as a
# dependency.
if (NOT CMAKE_PROJECT_NAME OR "${CMAKE_PROJECT_NAME}" STREQUAL "asmjit")
  project(asmjit
    LANGUAGES CXX
    DESCRIPTION "Low-latency machine code generation"
    HOMEPAGE_URL "https://asmjit.com")
endif()

set(ASMJIT_SANITIZE            "" CACHE STRING "Sanitizers to use (development)")
set(ASMJIT_SANITIZE_OPTS       "" CACHE STRING "Extra flags for sanitizers (development)")

option(ASMJIT_EMBED            "Embed 'asmjit' as an interface library (no static/shared library)" OFF)
option(ASMJIT_STATIC           "Build 'asmjit' as a static library (implied by ASMJIT_EMBED)" ${ASMJIT_EMBED})
option(ASMJIT_TEST             "Build 'asmjit' tests and benchmarks (development)" OFF)

option(ASMJIT_NO_NATVIS        "Disable natvis support (embedding asmjit.natvis in PDB)" OFF)
option(ASMJIT_NO_CUSTOM_FLAGS  "Disable extra compilation flags added by AsmJit to its targets" OFF)
option(ASMJIT_NO_ABI_NAMESPACE "Disable the use of inline ABI namespace {asmjit::v...}" OFF)
option(ASMJIT_NO_SHM_OPEN      "Disable the use of shm_open() (some platforms have better options)" OFF)
option(ASMJIT_NO_X86           "Disable X86/X64 backend" OFF)
option(ASMJIT_NO_AARCH64       "Disable AArch64 backend" OFF)
option(ASMJIT_NO_FOREIGN       "Disable all foreign backends (enables only a backend that matches the target)" OFF)
option(ASMJIT_NO_JIT           "Disable VirtMem, JitAllocator, and JitRuntime at build time" OFF)
option(ASMJIT_NO_TEXT          "Disable textual representation of instructions, enums, cpu features, ..." OFF)
option(ASMJIT_NO_LOGGING       "Disable logging features (build feature)" ${ASMJIT_NO_TEXT})
option(ASMJIT_NO_INTROSPECTION "Disable instruction validation and introspection API (build feature)" OFF)
option(ASMJIT_NO_BUILDER       "Disable AsmJit's Builder emitter (build feature)" OFF)

if (NOT ASMJIT_NO_BUILDER AND NOT ASMJIT_NO_INTROSPECTION)
  option(ASMJIT_NO_COMPILER    "Disable AsmJit's Compiler emitter (build feature)" OFF)
else()
  if (NOT ASMJIT_NO_COMPILER)
    unset(ASMJIT_NO_COMPILER CACHE)
  endif()
  option(ASMJIT_NO_COMPILER    "Disable AsmJit's Compiler emitter (build feature)" ON)
endif()

if (NOT ASMJIT_NO_COMPILER)
  option(ASMJIT_NO_UJIT        "Disable AsmJit's UniCompiler backend (build feature)" OFF)
else()
  if (NOT ASMJIT_NO_UJIT)
    unset(ASMJIT_NO_UJIT CACHE)
  endif()
  option(ASMJIT_NO_UJIT        "Disable AsmJit's UniCompiler backend (build feature)" ON)
endif()

# AsmJit - Build Definitions and Source Files
# ===========================================

set(ASMJIT_INCLUDE_DIRS "${CMAKE_CURRENT_LIST_DIR}") # AsmJit include directory is the same as <root> directory.
set(ASMJIT_LIBS "")                                  # AsmJit library dependencies for the linker.
set(ASMJIT_CFLAGS "")                                # Public compiler flags.
set(ASMJIT_PRIVATE_LFLAGS "")                        # Private linker flags independent of build type.
set(ASMJIT_PRIVATE_CFLAGS "")                        # Private compiler flags independent of build type.
set(ASMJIT_PRIVATE_CFLAGS_DBG "")                    # Private compiler flags used by debug builds.
set(ASMJIT_PRIVATE_CFLAGS_REL "")                    # Private compiler flags used by release builds.
set(ASMJIT_NOEXCEPT_CFLAGS "")                       # Compiler flags to prevent emitting code with exceptions.
set(ASMJIT_SANITIZE_CFLAGS "")                       # Compiler flags required by currently enabled sanitizers.
set(ASMJIT_SANITIZE_LFLAGS "")                       # Linker flags required by currently enabled sanitizers.

if (ASMJIT_EMBED)
  set(ASMJIT_TARGET_TYPE "EMBED")
elseif (ASMJIT_STATIC)
  set(ASMJIT_TARGET_TYPE "STATIC")
else()
  set(ASMJIT_TARGET_TYPE "SHARED")
endif()
message(STATUS "[asmjit] == Configuring AsmJit ('ASMJIT_TARGET_TYPE=${ASMJIT_TARGET_TYPE}') ==")

set(ASMJIT_TEST_SRC "")

function(asmjit_define_sources out)
  set(files_out_array "")
  set(tests_out_array ${ASMJIT_TEST_SRC})
  foreach(src_file ${ARGN})
    if ("${src_file}" MATCHES "_test\\.cpp$")
      list(APPEND tests_out_array ${src_file})
    else()
      list(APPEND files_out_array ${src_file})
    endif()
  endforeach()
  set(${out} "${files_out_array}" PARENT_SCOPE)
  set(ASMJIT_TEST_SRC "${tests_out_array}" PARENT_SCOPE)
endfunction()

# The axl library can be used independently by any AsmJit tool that doesn't require AsmJit itself.
asmjit_define_sources(ASMJIT_AXL_SRC
  asmjit/build_scope_begin.h
  asmjit/build_scope_end.h

  asmjit/axl/build_integration.h
  asmjit/axl/algorithm.h
  asmjit/axl/algorithm_test.cpp
  asmjit/axl/arena.cpp
  asmjit/axl/arena.h
  asmjit/axl/arena_test.cpp
  asmjit/axl/arena_bit_set.cpp
  asmjit/axl/arena_bit_set_p.h
  asmjit/axl/arena_bit_set_test.cpp
  asmjit/axl/arena_hash.cpp
  asmjit/axl/arena_hash.h
  asmjit/axl/arena_hash_test.cpp
  asmjit/axl/arena_list.h
  asmjit/axl/arena_list_test.cpp
  asmjit/axl/arena_pool.h
  asmjit/axl/arena_string.h
  asmjit/axl/arena_tree.h
  asmjit/axl/arena_tree_test.cpp
  asmjit/axl/arena_vector.cpp
  asmjit/axl/arena_vector.h
  asmjit/axl/arena_vector_test.cpp
  asmjit/axl/bit_set_ops.h
  asmjit/axl/bit_set_ops_test.cpp
  asmjit/axl/commons.h
  asmjit/axl/commons_test.cpp
  asmjit/axl/inplace_array.h
  asmjit/axl/inplace_bit_set.h
  asmjit/axl/inplace_queue.h
  asmjit/axl/inplace_stack.h
  asmjit/axl/inplace_storage.h
  asmjit/axl/inplace_string.h
  asmjit/axl/mem_alloc.h
  asmjit/axl/mem_ops.h
  asmjit/axl/mem_ops_test.cpp
  asmjit/axl/span.h
  asmjit/axl/string_index.h
  asmjit/axl/string_index_test.cpp
  asmjit/axl/string_utils.h
  asmjit/axl/string_utils_test.cpp
  asmjit/axl/support_p.h
)

asmjit_define_sources(ASMJIT_SRC
  asmjit/core.h
  asmjit/core/api_build_p.h
  asmjit/core/api_build_test_p.h
  asmjit/core/arch_traits.cpp
  asmjit/core/arch_traits.h
  asmjit/core/arch_commons.h
  asmjit/core/assembler.cpp
  asmjit/core/assembler.h
  asmjit/core/assembler_test_p.h
  asmjit/core/build_defs.h
  asmjit/core/builder.cpp
  asmjit/core/builder.h
  asmjit/core/code_buffer.h
  asmjit/core/code_holder.cpp
  asmjit/core/code_holder.h
  asmjit/core/code_holder_test.cpp
  asmjit/core/code_writer.cpp
  asmjit/core/code_writer_p.h
  asmjit/core/compiler.cpp
  asmjit/core/compiler.h
  asmjit/core/compiler_defs.h
  asmjit/core/compiler_test_p.h
  asmjit/core/const_pool.cpp
  asmjit/core/const_pool.h
  asmjit/core/const_pool_test.cpp
  asmjit/core/cpu_info.cpp
  asmjit/core/cpu_info.h
  asmjit/core/debug_utils.cpp
  asmjit/core/debug_utils.h
  asmjit/core/emit_helper.cpp
  asmjit/core/emit_helper_p.h
  asmjit/core/emitter.cpp
  asmjit/core/emitter.h
  asmjit/core/emitter_utils.cpp
  asmjit/core/emitter_utils_p.h
  asmjit/core/environment.cpp
  asmjit/core/environment.h
  asmjit/core/environment_test.cpp
  asmjit/core/error.cpp
  asmjit/core/error.h
  asmjit/core/error_handler.cpp
  asmjit/core/error_handler.h
  asmjit/core/fixup.h
  asmjit/core/formatter.cpp
  asmjit/core/formatter.h
  asmjit/core/func.cpp
  asmjit/core/func.h
  asmjit/core/func_test.cpp
  asmjit/core/func_args_context.cpp
  asmjit/core/func_args_context_p.h
  asmjit/core/globals.h
  asmjit/core/inst.cpp
  asmjit/core/inst.h
  asmjit/core/inst_db.cpp
  asmjit/core/inst_db_p.h
  asmjit/core/jit_allocator.cpp
  asmjit/core/jit_allocator.h
  asmjit/core/jit_allocator_test.cpp
  asmjit/core/jit_runtime.cpp
  asmjit/core/jit_runtime.h
  asmjit/core/jit_runtime_test.cpp
  asmjit/core/logger.cpp
  asmjit/core/logger.h
  asmjit/core/misc_p.h
  asmjit/core/operand.h
  asmjit/core/operand_test.cpp
  asmjit/core/os_utils.h
  asmjit/core/os_utils_p.h
  asmjit/core/pauth.cpp
  asmjit/core/pauth.h
  asmjit/core/pauth_utils_p.h
  asmjit/core/ra_assignment_p.h
  asmjit/core/ra_cfg_block_p.h
  asmjit/core/ra_cfg_builder_p.h
  asmjit/core/ra_constraints_p.h
  asmjit/core/ra_defs_p.h
  asmjit/core/ra_inst_p.h
  asmjit/core/ra_local.cpp
  asmjit/core/ra_local_p.h
  asmjit/core/ra_pass.cpp
  asmjit/core/ra_pass_p.h
  asmjit/core/ra_reg_p.h
  asmjit/core/ra_stack.cpp
  asmjit/core/ra_stack_p.h
  asmjit/core/string.cpp
  asmjit/core/string.h
  asmjit/core/string_test.cpp
  asmjit/core/target.cpp
  asmjit/core/target.h
  asmjit/core/type.cpp
  asmjit/core/type.h
  asmjit/core/virt_mem.cpp
  asmjit/core/virt_mem.h
  asmjit/core/virt_mem_p.h
  asmjit/core/virt_mem_test.cpp

  asmjit/a64.h
  asmjit/arm.h
  asmjit/arm/arm_formatter.cpp
  asmjit/arm/arm_formatter_p.h
  asmjit/arm/arm_globals.h
  asmjit/arm/arm_utils.h
  asmjit/arm/a64_arch_traits_p.h
  asmjit/arm/a64_arch_traits_test.cpp
  asmjit/arm/a64_assembler.cpp
  asmjit/arm/a64_assembler_test.cpp
  asmjit/arm/a64_assembler.h
  asmjit/arm/a64_builder.cpp
  asmjit/arm/a64_builder.h
  asmjit/arm/a64_builder_test.cpp
  asmjit/arm/a64_compiler.cpp
  asmjit/arm/a64_compiler.h
  asmjit/arm/a64_compiler_test.cpp
  asmjit/arm/a64_emit_helper.cpp
  asmjit/arm/a64_emit_helper_p.h
  asmjit/arm/a64_emitter.h
  asmjit/arm/a64_formatter.cpp
  asmjit/arm/a64_formatter_p.h
  asmjit/arm/a64_formatter_test.cpp
  asmjit/arm/a64_func.cpp
  asmjit/arm/a64_func_p.h
  asmjit/arm/a64_globals.h
  asmjit/arm/a64_inst_api.cpp
  asmjit/arm/a64_inst_api_p.h
  asmjit/arm/a64_inst_db.cpp
  asmjit/arm/a64_inst_db.h
  asmjit/arm/a64_inst_test.cpp
  asmjit/arm/a64_operand.h
  asmjit/arm/a64_operand_test.cpp
  asmjit/arm/a64_ra_pass.cpp
  asmjit/arm/a64_ra_pass_p.h

  asmjit/x86.h
  asmjit/x86/x86_arch_traits_p.h
  asmjit/x86/x86_arch_traits_test.cpp
  asmjit/x86/x86_assembler.cpp
  asmjit/x86/x86_assembler_enc32_test.cpp
  asmjit/x86/x86_assembler_enc64_test.cpp
  asmjit/x86/x86_assembler.h
  asmjit/x86/x86_builder.cpp
  asmjit/x86/x86_builder.h
  asmjit/x86/x86_builder_test.cpp
  asmjit/x86/x86_compiler.cpp
  asmjit/x86/x86_compiler.h
  asmjit/x86/x86_compiler_test.cpp
  asmjit/x86/x86_emit_helper.cpp
  asmjit/x86/x86_emit_helper_p.h
  asmjit/x86/x86_emitter.h
  asmjit/x86/x86_formatter.cpp
  asmjit/x86/x86_formatter_p.h
  asmjit/x86/x86_formatter_test.cpp
  asmjit/x86/x86_func.cpp
  asmjit/x86/x86_func_p.h
  asmjit/x86/x86_globals.h
  asmjit/x86/x86_inst_api.cpp
  asmjit/x86/x86_inst_api_p.h
  asmjit/x86/x86_inst_db.cpp
  asmjit/x86/x86_inst_db.h
  asmjit/x86/x86_inst_db_p.h
  asmjit/x86/x86_inst_test.cpp
  asmjit/x86/x86_opcode_p.h
  asmjit/x86/x86_operand.h
  asmjit/x86/x86_operand_test.cpp
  asmjit/x86/x86_ra_pass.cpp
  asmjit/x86/x86_ra_pass_p.h

  asmjit/ujit.h
  asmjit/ujit/ujit_base.h
  asmjit/ujit/uni_compiler.h
  asmjit/ujit/uni_compiler_a64.cpp
  asmjit/ujit/uni_compiler_x86.cpp
  asmjit/ujit/uni_compiler_utils_p.h
  asmjit/ujit/uni_compiler_test.cpp
  asmjit/ujit/uni_condition.h
  asmjit/ujit/uni_op.h
  asmjit/ujit/vec_const_table.cpp
  asmjit/ujit/vec_const_table.h
)

set(ASMJIT_SRC ${ASMJIT_AXL_SRC} asmjit/host.h ${ASMJIT_SRC})

# AsmJit - CMake Utilities
# ========================

include(CheckCXXCompilerFlag)
include(CheckCXXSourceCompiles)
include(GNUInstallDirs)

# Detects target architecture - since the code doesn't run it works also for cross-compilation.
function(asmjit_detect_target_arch out)
  set(${out} "unknown" PARENT_SCOPE)
  foreach(target_arch "X86_64" "AARCH64" "X86" "AARCH32")
    check_cxx_source_compiles("
      #if defined(_M_X64) || defined(__x86_64__)
        static int target_arch_is_X86_64() { return 1; }
      #elif defined(_M_IX86) || defined(__X86__) || defined(__i386__)
        static int target_arch_is_X86() { return 1; }
      #elif defined(_M_ARM64) || defined(__arm64__) || defined(__aarch64__)
        static int target_arch_is_AARCH64() { return 1; }
      #elif defined(_M_ARM) || defined(_M_ARMT) || defined(__arm__) || defined(__thumb__) || defined(__thumb2__)
        static int target_arch_is_AARCH32() { return 1; }
      #endif
      int main(void) { return target_arch_is_${target_arch}(); }" "${out}_${target_arch}")
    if (${${out}_${target_arch}})
      set(${out} "${target_arch}" PARENT_SCOPE)
      return()
    endif()
  endforeach()
endfunction()

# Detects C++ compile flags and appends all detected ones to `out`.
function(asmjit_detect_cflags out)
  set(out_array ${${out}})
  foreach(flag ${ARGN})
    string(REGEX REPLACE "[+]" "x" flag_signature "${flag}")
    string(REGEX REPLACE "[-=:;/.\]" "_" flag_signature "${flag_signature}")
    check_cxx_compiler_flag(${flag} "__CxxFlag_${flag_signature}")
    if (${__CxxFlag_${flag_signature}})
      list(APPEND out_array "${flag}")
    endif()
  endforeach()
  set(${out} "${out_array}" PARENT_SCOPE)
endfunction()

# Support for various sanitizers provided by C/C++ compilers.
function(asmjit_detect_sanitizers out)
  set(_out_array ${${out}})
  set(_flags "")

  foreach(_arg ${ARGN})
    string(REPLACE "," ";" _arg "${_arg}")
    list(APPEND _flags ${_arg})
  endforeach()

  foreach(_flag ${_flags})
    if (NOT "${_flag}" MATCHES "^-fsanitize=")
      SET(_flag "-fsanitize=${_flag}")
    endif()

    # Sanitizers also require link flags, see CMAKE_REQUIRED_FLAGS.
    set(CMAKE_REQUIRED_FLAGS "${_flag}")
    asmjit_detect_cflags(_out_array ${_flag})
    unset(CMAKE_REQUIRED_FLAGS)
  endforeach()

  set(${out} "${_out_array}" PARENT_SCOPE)
endfunction()

function(asmjit_add_target target target_type)
  set(single_val "")
  set(multi_val SOURCES LIBRARIES CFLAGS CFLAGS_DBG CFLAGS_REL LFLAGS)
  cmake_parse_arguments("X" "" "${single_val}" "${multi_val}" ${ARGN})

  if ("${target_type}" MATCHES "^(EXECUTABLE|TEST)$")
    add_executable(${target} ${X_SOURCES})
  else()
    add_library(${target} ${target_type} ${X_SOURCES})
  endif()

  set_target_properties(${target}
    PROPERTIES
      DEFINE_SYMBOL ""
      CXX_VISIBILITY_PRESET hidden)
  target_compile_options(${target} PRIVATE ${X_CFLAGS} ${ASMJIT_SANITIZE_CFLAGS} $<$<CONFIG:Debug>:${X_CFLAGS_DBG}> $<$<NOT:$<CONFIG:Debug>>:${X_CFLAGS_REL}>)
  target_compile_features(${target} PUBLIC cxx_std_20)
  target_link_options(${target} PRIVATE ${X_LFLAGS} ${ASMJIT_SANITIZE_LFLAGS})
  target_link_libraries(${target} PRIVATE ${X_LIBRARIES})

  if ("${target_type}" STREQUAL "TEST")
    add_test(NAME ${target} COMMAND ${target})
  endif()
endfunction()

# AsmJit - Compiler Support
# =========================

if (NOT ASMJIT_EMBED)
  if (NOT ASMJIT_NO_CUSTOM_FLAGS)
    if ("${CMAKE_CXX_COMPILER_ID}" STREQUAL "MSVC" OR "x${CMAKE_CXX_COMPILER_FRONTEND_VARIANT}" STREQUAL "xMSVC")
      list(APPEND ASMJIT_PRIVATE_CFLAGS -W4)                                      # [+] Warning level 4.

      list(APPEND ASMJIT_PRIVATE_CFLAGS -MP)                                      # [+] Multi-Process Compilation.
      list(APPEND ASMJIT_PRIVATE_CFLAGS -GF)                                      # [+] Eliminate duplicate strings.
      list(APPEND ASMJIT_PRIVATE_CFLAGS -Zc:__cplusplus)                          # [+] Conforming __cplusplus definition.
      list(APPEND ASMJIT_PRIVATE_CFLAGS -Zc:inline)                               # [+] Remove unreferenced COMDAT.
      list(APPEND ASMJIT_PRIVATE_CFLAGS -Zc:strictStrings)                        # [+] Strict const qualification of string literals.
      list(APPEND ASMJIT_PRIVATE_CFLAGS -Zc:threadSafeInit-)                      # [-] Thread-safe statics.

      list(APPEND ASMJIT_PRIVATE_CFLAGS_DBG -GS)                                  # [+] Buffer security-check.
      list(APPEND ASMJIT_PRIVATE_CFLAGS_REL -GS-)                                 # [-] Buffer security-check.
      list(APPEND ASMJIT_PRIVATE_CFLAGS_REL -O2)                                  # [+] Favor speed over size.
      list(APPEND ASMJIT_PRIVATE_CFLAGS_REL -Oi)                                  # [+] Generate intrinsic functions.
    elseif ("${CMAKE_CXX_COMPILER_ID}" MATCHES "GNU|Clang")
      list(APPEND ASMJIT_PRIVATE_CFLAGS -Wall -Wextra -Wconversion)               # [+] Add baseline warnings that can be used safely even with system headers.
      list(APPEND ASMJIT_NOEXCEPT_CFLAGS "-fno-exceptions")

      asmjit_detect_cflags(ASMJIT_PRIVATE_CFLAGS -Wdouble-promotion)              # [+] Warn about double promotions.
      asmjit_detect_cflags(ASMJIT_PRIVATE_CFLAGS -Wduplicated-cond)               # [+] Warn about duplicate conditions.
      asmjit_detect_cflags(ASMJIT_PRIVATE_CFLAGS -Wduplicated-branches)           # [+] Warn about duplicate branches.
      asmjit_detect_cflags(ASMJIT_PRIVATE_CFLAGS -Wlogical-op)                    # [+] Warn about suspicious uses of logical operators in expressions.
      asmjit_detect_cflags(ASMJIT_PRIVATE_CFLAGS -Wlogical-not-parentheses)       # [+] Warn about logical not used on the left hand side operand of a comparison.
      asmjit_detect_cflags(ASMJIT_PRIVATE_CFLAGS -Wrestrict)

      # TODO: Future plans to avoid linking to the standard C++ library we don't need.
      # if ("${ASMJIT_TARGET_TYPE}" STREQUAL "SHARED")
      #   list(APPEND ASMJIT_PRIVATE_LFLAGS -nostdlib++)
      # endif()

      list(APPEND ASMJIT_PRIVATE_CFLAGS -fno-math-errno)                          # [-] Disable math functions setting errno (performance reasons).
      list(APPEND ASMJIT_PRIVATE_CFLAGS -fno-threadsafe-statics)                  # [-] Don't add guards when initializing statics (we don't need it).
      list(APPEND ASMJIT_PRIVATE_CFLAGS_REL -O2)                                  # [+] Compiling with -O2 in release mode is what we generally want.
      list(APPEND ASMJIT_PRIVATE_CFLAGS_REL -fmerge-all-constants)                # [+] We don't need unique address per constant (merging improves library size).

      # -fno-semantic-interposition is not available on apple - the compiler issues a warning, which is not detected.
      if (NOT APPLE)
        asmjit_detect_cflags(ASMJIT_PRIVATE_CFLAGS -fno-semantic-interposition)
      endif()

      if (NOT "${CMAKE_SYSTEM_NAME}" STREQUAL "iOS")
        asmjit_detect_cflags(ASMJIT_PRIVATE_CFLAGS_REL -fno-enforce-eh-specs)     # [-] Don't enforce termination if noexcept function throws.
      endif()
    endif()
  endif()

  # Support for sanitizers.
  if (ASMJIT_SANITIZE)
    asmjit_detect_sanitizers(ASMJIT_SANITIZE_CFLAGS ${ASMJIT_SANITIZE})
    if (ASMJIT_SANITIZE_CFLAGS)
      message(STATUS "[asmjit] Enabling sanitizers: '${ASMJIT_SANITIZE_CFLAGS}'")

      # Linker must receive the same flags as the compiler when it comes to sanitizers.
      set(ASMJIT_SANITIZE_LFLAGS ${ASMJIT_SANITIZE_CFLAGS})

      # Don't omit frame pointer if sanitizers are enabled.
      if ("${CMAKE_CXX_COMPILER_ID}" STREQUAL "MSVC" OR "x${CMAKE_CXX_COMPILER_FRONTEND_VARIANT}" STREQUAL "xMSVC")
        list(APPEND ASMJIT_SANITIZE_CFLAGS -Oy-)
      else()
        list(APPEND ASMJIT_SANITIZE_CFLAGS -fno-omit-frame-pointer -g)
      endif()
    endif()
  endif()
endif()

if ("${CMAKE_SYSTEM_NAME}" MATCHES "^Windows")
  # Dependency: Windows target needs no extra dependencies, however, we have to check for .natvis support.
  if(CMAKE_LINKER MATCHES "^(lld-link|link)\\.exe$")
    set(ASMJIT_LINKER_SUPPORTS_NATVIS TRUE)
  endif()
elseif ("${CMAKE_SYSTEM_NAME}" STREQUAL "Android")
  # Dependency: libc is the only required library on Android as it also provides libpthread.
  message(STATUS "[asmjit] Adding 'libc' dependency (Android)")
  list(APPEND ASMJIT_LIBS c)
elseif ("${CMAKE_SYSTEM_NAME}" STREQUAL "Haiku")
  # Dependency: libroot is used by Haiku instead of libc, so link to libroot and libpthread.
  message(STATUS "[asmjit] Adding 'libroot' and 'libpthread' dependencies (Haiku)")
  list(APPEND ASMJIT_LIBS root pthread)
else()
  # Dependency: libc is always required.
  message(STATUS "[asmjit] Adding 'libc' dependency (Linux, BSD, or other UNIX/POSIX environment)")
  list(APPEND ASMJIT_LIBS c)

  # Dependency: pthread (required so AsmJit can use pthread_lock).
  check_cxx_source_compiles("
    #include <pthread.h>
    int main() {
      pthread_mutex_t m;
      pthread_mutex_init(&m, nullptr);
      return pthread_mutex_destroy(&m);
    }
    " ASMJIT_LIBC_HAS_LIBPTHREAD)
  if (ASMJIT_LIBC_HAS_LIBPTHREAD)
    message(STATUS "[asmjit] Library 'libpthread' provided by 'libc' (not linking to libpthread)")
  else()
    message(STATUS "[asmjit] Library 'libpthread' not provided by 'libc' (linking to libpthread)")
    list(APPEND ASMJIT_LIBS pthread)
  endif()

  # Dependency: shm_open (required so AsmJit can use shm_open on supported platforms).
  if ("${CMAKE_SYSTEM_NAME}" MATCHES "^(Linux|NetBSD)$" AND NOT ASMJIT_NO_SHM_OPEN)
    check_cxx_source_compiles("
      #include <sys/mman.h>
      int main() {
        const char file_name[1] {};
        return shm_open(file_name, 0, 0);
      }
      " ASMJIT_LIBC_HAS_LIBRT)
    if (ASMJIT_LIBC_HAS_LIBRT)
      message(STATUS "[asmjit] Symbol 'shm_open' provided by libc (not linking to librt)")
    else()
      message(STATUS "[asmjit] Symbol 'shm_open' not provided by libc, linking to librt")
      list(APPEND ASMJIT_LIBS rt)
    endif()
  endif()
endif()

if (ASMJIT_STATIC OR ASMJIT_EMBED)
  list(APPEND ASMJIT_CFLAGS -DASMJIT_STATIC)
endif()

if (ASMJIT_NO_SHM_OPEN)
  list(APPEND ASMJIT_PRIVATE_CFLAGS -DASMJIT_NO_SHM_OPEN)
endif()

foreach(build_option ASMJIT_NO_X86
                     ASMJIT_NO_AARCH64
                     ASMJIT_NO_FOREIGN
                     ASMJIT_NO_ABI_NAMESPACE
                     ASMJIT_NO_JIT
                     ASMJIT_NO_TEXT
                     ASMJIT_NO_LOGGING
                     ASMJIT_NO_INTROSPECTION
                     ASMJIT_NO_BUILDER
                     ASMJIT_NO_COMPILER
                     ASMJIT_NO_UJIT)
  if (${build_option})
    list(APPEND ASMJIT_CFLAGS "-D${build_option}")
  endif()
endforeach()

if (ASMJIT_LINKER_SUPPORTS_NATVIS AND NOT ASMJIT_NO_NATVIS)
  list(APPEND ASMJIT_SRC asmjit/asmjit.natvis)
  list(APPEND ASMJIT_PRIVATE_LFLAGS "-natvis:${CMAKE_CURRENT_LIST_DIR}/asmjit/asmjit.natvis")
endif()

source_group(TREE "${CMAKE_CURRENT_LIST_DIR}" FILES ${ASMJIT_SRC})

# AsmJit - Targets
# ================

if (TRUE)
  message(STATUS "[asmjit] Adding 'asmjit::asmjit' target ('ASMJIT_TARGET_TYPE=${ASMJIT_TARGET_TYPE}')")

  if (ASMJIT_EMBED)
    add_library(asmjit_embed INTERFACE)
    target_sources(asmjit_embed INTERFACE ${ASMJIT_SRC})
    target_link_libraries(asmjit_embed INTERFACE ${ASMJIT_LIBS})
    target_compile_options(asmjit_embed INTERFACE ${ASMJIT_CFLAGS})
    target_include_directories(asmjit_embed BEFORE INTERFACE ${ASMJIT_INCLUDE_DIRS})
    add_library(asmjit::asmjit ALIAS asmjit_embed)
  else()
    foreach(v "ASMJIT_LIBS"
              "ASMJIT_CFLAGS"
              "ASMJIT_PRIVATE_CFLAGS"
              "ASMJIT_PRIVATE_CFLAGS_DBG"
              "ASMJIT_PRIVATE_CFLAGS_REL"
              "ASMJIT_SANITIZE_CFLAGS"
              "ASMJIT_SANITIZE_LFLAGS")
      if (NOT "${${v}}" STREQUAL "")
        message("   ${v}=${${v}}")
      endif()
    endforeach()

    # This file should really be compiled without exceptions, otherwise compilers generate calls to
    # std::terminate, which results in two problems - C++ standard library is required and the resulting
    # binary is larger (because of implicit throw/catch blocks to handle exceptions, which are never used).
    #
    # This can be disabled by `ASMJIT_NO_CUSTOM_FLAGS` option, which disables the use of any compiler flags.
    set_property(SOURCE asmjit/core/virt_mem.cpp APPEND PROPERTY COMPILE_OPTIONS ${ASMJIT_NOEXCEPT_CFLAGS})

    asmjit_add_target(asmjit "${ASMJIT_TARGET_TYPE}"
      SOURCES    ${ASMJIT_SRC}
      LIBRARIES  ${ASMJIT_LIBS}
      LFLAGS     ${ASMJIT_PRIVATE_LFLAGS}
      CFLAGS     ${ASMJIT_PRIVATE_CFLAGS}
      CFLAGS_DBG ${ASMJIT_PRIVATE_CFLAGS_DBG}
      CFLAGS_REL ${ASMJIT_PRIVATE_CFLAGS_REL})

    target_compile_options(asmjit PUBLIC ${ASMJIT_CFLAGS})
    target_include_directories(asmjit BEFORE PUBLIC $<BUILD_INTERFACE:${ASMJIT_INCLUDE_DIRS}>
                                                    $<INSTALL_INTERFACE:${CMAKE_INSTALL_INCLUDEDIR}>)
    add_library(asmjit::asmjit ALIAS asmjit)

    # AsmJit - Install Instructions
    # -----------------------------

    if (NOT ASMJIT_NO_INSTALL)
      message(STATUS "[asmjit] Enabling install support ('ASMJIT_NO_INSTALL=OFF')")

      install(TARGETS asmjit
              EXPORT asmjit-config
              RUNTIME DESTINATION "${CMAKE_INSTALL_BINDIR}"
              ARCHIVE DESTINATION "${CMAKE_INSTALL_LIBDIR}"
              LIBRARY DESTINATION "${CMAKE_INSTALL_LIBDIR}"
              INCLUDES DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}")

      install(EXPORT asmjit-config
              NAMESPACE asmjit::
              DESTINATION "${CMAKE_INSTALL_LIBDIR}/cmake/asmjit")

      foreach(_src_file ${ASMJIT_SRC})
        if ("${_src_file}" MATCHES "\\.h$" AND NOT "${_src_file}" MATCHES "_p\\.h$")
          get_filename_component(_src_dir ${_src_file} PATH)
          install(FILES "${CMAKE_CURRENT_LIST_DIR}/${_src_file}" DESTINATION "${CMAKE_INSTALL_INCLUDEDIR}/${_src_dir}")
        endif()
      endforeach()
    endif()

    # AsmJit - Tests & Benchmarks
    # ---------------------------

    if (ASMJIT_TEST)
      enable_testing()
      message(STATUS "[asmjit] Enabling AsmJit tests ('ASMJIT_TEST=${ASMJIT_TEST}')")

      # Vectorcall tests and XMM tests require at least SSE2 in 32-bit mode (in 64-bit mode it's implicit).
      # Some compilers don't like passing -msse2 for 64-bit targets, and some compilers targeting non-x86
      # would pass "-msse2" compile flag check, but with a warning not detected by CMake. Thus, verify that
      # our target is really 32-bit X86 and only use -msse2 or -arch:SSE2 flags when necessary.
      asmjit_detect_target_arch(ASMJIT_TARGET_ARCH)

      set(ASMJIT_SSE2_CFLAGS "")
      if ("${CMAKE_CXX_COMPILER_ID}" STREQUAL "MSVC" OR "x${CMAKE_CXX_COMPILER_FRONTEND_VARIANT}" STREQUAL "xMSVC")
        if (ASMJIT_TARGET_ARCH STREQUAL "X86")
          asmjit_detect_cflags(ASMJIT_SSE2_CFLAGS -arch:SSE2)
        endif()
      else()
        if (ASMJIT_TARGET_ARCH STREQUAL "X86")
          asmjit_detect_cflags(ASMJIT_SSE2_CFLAGS -msse2)
        endif()
      endif()

      # asmjit_test_runner - optimize static builds (no need to build AsmJit twice).
      set(ASMJIT_TEST_RUNNER_SRC
        asmjit-testing/commons/zero_lib.cpp
        asmjit-testing/commons/zero_lib.h
        asmjit-testing/commons/zero_test.cpp
        asmjit-testing/commons/zero_test.h
        asmjit-testing/tests/asmjit_test_runner.cpp
      )
      if (ASMJIT_STATIC)
        asmjit_add_target(asmjit_test_runner TEST
          SOURCES    ${ASMJIT_TEST_SRC} ${ASMJIT_TEST_RUNNER_SRC}
          LIBRARIES  ${ASMJIT_LIBS} asmjit::asmjit
          CFLAGS     ${ASMJIT_CFLAGS} ${ASMJIT_PRIVATE_CFLAGS} ${ASMJIT_SSE2_CFLAGS} -DASMJIT_TEST
          CFLAGS_DBG ${ASMJIT_PRIVATE_CFLAGS_DBG}
          CFLAGS_REL ${ASMJIT_PRIVATE_CFLAGS_REL})
      else()
        asmjit_add_target(asmjit_test_runner TEST
          SOURCES    ${ASMJIT_SRC} ${ASMJIT_TEST_SRC} ${ASMJIT_TEST_RUNNER_SRC}
          LIBRARIES  ${ASMJIT_LIBS}
          CFLAGS     ${ASMJIT_CFLAGS} ${ASMJIT_PRIVATE_CFLAGS} ${ASMJIT_SSE2_CFLAGS} -DASMJIT_TEST -DASMJIT_STATIC
          CFLAGS_DBG ${ASMJIT_PRIVATE_CFLAGS_DBG}
          CFLAGS_REL ${ASMJIT_PRIVATE_CFLAGS_REL})
      endif()
      target_include_directories(asmjit_test_runner BEFORE PRIVATE ${ASMJIT_INCLUDE_DIRS})

      foreach(app asmjit_test_cpu_info
                  asmjit_test_environment
                  asmjit_test_emitters
                  asmjit_test_rlimit
                  asmjit_test_x86_sections
                  asmjit_test_struct_sizes)
        asmjit_add_target(${app} TEST
          SOURCES    asmjit-testing/tests/${app}.cpp
          LIBRARIES  asmjit::asmjit
          CFLAGS     ${ASMJIT_PRIVATE_CFLAGS}
          CFLAGS_DBG ${ASMJIT_PRIVATE_CFLAGS_DBG}
          CFLAGS_REL ${ASMJIT_PRIVATE_CFLAGS_REL})
      endforeach()

      if (NOT ASMJIT_NO_INTROSPECTION)
        asmjit_add_target(asmjit_test_inst_info TEST
          SOURCES    asmjit-testing/tests/asmjit_test_inst_info.cpp
          LIBRARIES  asmjit::asmjit
          CFLAGS     ${ASMJIT_PRIVATE_CFLAGS}
          CFLAGS_DBG ${ASMJIT_PRIVATE_CFLAGS_DBG}
          CFLAGS_REL ${ASMJIT_PRIVATE_CFLAGS_REL})
      endif()

      asmjit_add_target(asmjit_bench_codegen EXECUTABLE
        SOURCES    asmjit-testing/bench/asmjit_bench_codegen.cpp
                   asmjit-testing/bench/asmjit_bench_codegen_a64.cpp
                   asmjit-testing/bench/asmjit_bench_codegen_x86.cpp
        SOURCES    asmjit-testing/bench/asmjit_bench_codegen.h
        LIBRARIES  asmjit::asmjit
        CFLAGS     ${ASMJIT_PRIVATE_CFLAGS}
        CFLAGS_DBG ${ASMJIT_PRIVATE_CFLAGS_DBG}
        CFLAGS_REL ${ASMJIT_PRIVATE_CFLAGS_REL})

      foreach(app asmjit_bench_calls asmjit_bench_overhead asmjit_bench_regalloc)
        asmjit_add_target(${app} TEST
          SOURCES    asmjit-testing/commons/zero_lib.cpp
                     asmjit-testing/commons/zero_lib.h
                     asmjit-testing/commons/zero_bench.cpp
                     asmjit-testing/commons/zero_bench.h
                     asmjit-testing/bench/${app}.cpp
          LIBRARIES  asmjit::asmjit
          CFLAGS     ${ASMJIT_PRIVATE_CFLAGS}
          CFLAGS_DBG ${ASMJIT_PRIVATE_CFLAGS_DBG}
          CFLAGS_REL ${ASMJIT_PRIVATE_CFLAGS_REL})
      endforeach()

    endif()
  endif()
endif()

message(STATUS "[asmjit] == Configuring done ==")
